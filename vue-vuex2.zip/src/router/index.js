import { createRouter, createWebHistory } from 'vue-router'
import CardsView from '../views/CardsView.vue'
import InformacionView from '../views/InformacionView.vue'
import ListCartelera from '../views/ListCartelera.vue'
import Listamemes from '../views/Listamemes.vue' //
const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'cards',
      component: CardsView
    },
    {
      path: '/informacion',
      name: 'informacion',
      component: InformacionView
    },
    {
      path: '/Listamemes',
      name: 'Listamemes',
      component: Listamemes
    },
    {
      path: '/ListCartelera',
      name: 'ListCartelera',
      component: ListCartelera
    }
  ]
})

export default router
