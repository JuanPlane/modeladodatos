import { createStore } from 'vuex'

export default createStore({
  state: {
    titleApp: 'meme',
    lista: [
      {
        titulo: 'Twitter',
        imagen:
          'https://ih1.redbubble.net/image.3884803808.9824/bg,f8f8f8-flat,750x,075,f-pad,750x1000,f8f8f8.jpg',
        descripcion: 'Texto de ejemplo, texto de ejemplo, texto de ejemplo, texto de ejemplo'
      },
      {
        titulo: 'arbol',
        imagen: 'arbol.jpg',
        descripcion: 'Texto de ejemplo, texto de ejemplo, texto de ejemplo, texto de ejemplo'
      },
      {
        titulo: 'bombilla',
        imagen: 'bombilla.jpg',
        descripcion: 'Texto de ejemplo, texto de ejemplo, texto de ejemplo, texto de ejemplo'
      },
      {
        titulo: 'fondo',
        imagen: 'fondo.jpg',
        descripcion: 'Texto de ejemplo, texto de ejemplo, texto de ejemplo, texto de ejemplo'
      },
      {
        titulo: 'fuego',
        imagen: 'fuego.jpg',
        descripcion: 'Texto de ejemplo, texto de ejemplo, texto de ejemplo, texto de ejemplo'
      },
      {
        titulo: 'meme',
        imagen: 'meme.jpg',
        descripcion: 'Texto de ejemplo, texto de ejemplo, texto de ejemplo, texto de ejemplo'
      }
    ],
    pokemons: []
  },
  getters: {},
  mutations: {
    setPokemons(state, payload) {
      state.pokemons = payload
    }
  },
  actions: {
    async getPokemons({ commit }) {
      try {
        const response = await fetch(
          'https://raw.githubusercontent.com/robert-z/simple-pokemon-json-api/master/data/pokemon.json'
        )
        const result = await response.json()
        commit('setPokemons', result)
        console.log(result)
      } catch (error) {
        console.log(error)
      }
    },
    async getMemes({ commit }) {
      try {
        const response = await fetch('https://api.example.com/memes')
        const result = await response.json()
        // Procesar el resultado y hacer los commits necesarios
        console.log(result)
      } catch (error) {
        console.log(error)
      }
    }
  },
  modules: {},
  titulo: 'meme',
  imagen: 'meme.jpg',
  descripcion: 'Texto de ejemplo, texto de ejemplo, texto de ejemplo, texto de ejemplo'
})
