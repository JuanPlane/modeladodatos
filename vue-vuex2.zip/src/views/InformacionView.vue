<template>
  <div class="container">
    <div class="col-8">
      <div class="card">
        <div class="card-body">
          <h1 class="text-left card-title">Titulo</h1>
          <p class="card-text">
            Texto de ejemplo, texto de ejemplo, texto de ejemplo, texto de ejemplo Texto de ejemplo,
            texto de ejemplo, texto de ejemplo, texto de Texto de ejemplo, texto de ejemplo, texto
            de ejemplo, texto de ejemplo ejemplo
          </p>
          <img class="card-img-bottom" src="../assets/twitter.jpg" alt="" />
          <div class="row">
            <div class="btn-group">
              <RouterLink to="/" class="btn btn-primary ms-5">Volver</RouterLink>
              <button
                type="button"
                class="btn btn-primary dropdown-toggle ms-5"
                data-bs-toggle="dropdown"
                aria-haspopup="true"
                aria-expanded="false"
              >
                <span>Acciones</span>
              </button>
              <div class="dropdown-menu">
                <!-- Contenido del dropdown -->
                <a class="dropdown-item" href="#">Guardar favorito</a>
                <a class="dropdown-item" href="#">Exportar PDF</a>
                <a class="dropdown-item" href="#">Imprimir</a>
                <a class="dropdown-item" href="#">Compartir</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { RouterLink } from 'vue-router'
export default {
  setup() {
    return {
      RouterLink
    }
  }
}
</script>

<style lang="scss" scoped></style>
