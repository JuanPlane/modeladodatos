<template>
  <div class="container">
    <div class="mt-3 row">
      <div class="col">
        <div class="card">
          <div class="text-center card-body">
            <h1>Cabecera</h1>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="card col-4" v-for="item in $store.state.lista">
        <img class="card-img-top" :src="item.imagen" alt="" />
        <div class="card-body">
          <div class="card-body">
            <h5 class="text-center card-title">{{ item.titulo }}</h5>
            <p class="text-center card-text">{{ item.descripcion }}</p>
            <RouterLink to="/informacion" class="mx-auto btn btn-primary d-block"
              >Mas informacion</RouterLink
            >
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { RouterLink } from 'vue-router'
import { useStore } from 'vuex'

export default {
  setup() {
    const store = useStore()
    return {
      RouterLink,
      ...store.state
    }
  }
}
</script>

<style lang="scss" scoped></style>
