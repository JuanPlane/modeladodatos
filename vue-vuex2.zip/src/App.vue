<template>
  <nav>
    <router-link to="/Listacartelera">cartelera</router-link>
    <router-link to="/Listamemes">memes</router-link>
  </nav>
  <ListPokemon />
  <Listacartelera />
  <Listamemes />
</template>

<script>
import ListPokemon from './components/ListPokemon.vue'
import Listacartelera from './components/ListCartelera.vue'
import ListMeme from './components/Listamemes.vue'

export default {
  name: 'App',
  components: { ListPokemon, Listacartelera, ListMeme }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

nav {
  padding: 30px;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
}

nav a.router-link-exact-active {
  color: #42b983;
}
</style>
