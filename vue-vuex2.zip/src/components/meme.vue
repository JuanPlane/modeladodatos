<template>
  <div class="card col-4">
    <img
      class="card-img-top"
      :src="'https://api.imgflip.com/get_memes' + meme.num + '.png'"
      alt=""
    />
    <div class="card-body">
      <div class="card-body">
        <h5 class="text-center card-title">{{ props.meme.variations[0].name }}</h5>
        <p class="text-center card-text">{{ props.meme.variations[0].description }}</p>
        <a :href="props.meme.link" class="mx-auto btn btn-primary d-block">Mas informacion</a>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    meme: Object
  },
  setup(props) {
    return {
      props
    }
  }
}
</script>

<style lang="scss" scoped></style>
