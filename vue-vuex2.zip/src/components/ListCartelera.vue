<template>
  <div class="container">
    <div class="text-center">
      <h1>{{ title }}</h1>
    </div>
    <div class="row">
      <template v-for="cartelera in cartelera" :key="cartelera.id">
        <Cartelera :cartelera="cartelera" />
      </template>
    </div>
  </div>
</template>

<script>
import { onMounted, computed } from 'vue'
import { useStore } from 'vuex'
import Cartelera from './Cartelera.vue'

export default {
  components: { Cartelera },
  setup() {
    const store = useStore()
    onMounted(() => {
      store.dispatch('getCartelera')
    })
    const cartelera = computed(() => store.state.cartelera)

    return {
      title: store.state.titleApp,
      cartelera
    }
  }
}
</script>

<style lang="scss" scoped></style>
