<template>
  <div class="card col-4">
    <img
      class="card-img-top"
      :src="
        'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/' +
        pokemon.num +
        '.png'
      "
      alt=""
    />
    <div class="card-body">
      <div class="card-body">
        <h5 class="text-center card-title">{{ props.pokemon.variations[0].name }}</h5>
        <p class="text-center card-text">{{ props.pokemon.variations[0].description }}</p>
        <a :href="props.pokemon.link" class="mx-auto btn btn-primary d-block">Mas informacion</a>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    pokemon: Object
  },
  setup(props) {
    return {
      props
    }
  }
}
</script>

<style lang="scss" scoped></style>
