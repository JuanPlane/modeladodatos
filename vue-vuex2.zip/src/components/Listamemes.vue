<template>
  <div class="container">
    <div class="text-center">
      <h1>{{ title }}</h1>
    </div>
    <div class="row">
      <template v-for="meme in meme" :key="meme.id">
        <meme :meme="meme" />
      </template>
    </div>
  </div>
</template>

<script>
import { onMounted, computed } from 'vue'
import { useStore } from 'vuex'
import meme from './meme.vue'

export default {
  components: { meme },
  setup() {
    const store = useStore()
    onMounted(() => {
      store.dispatch('getmeme')
    })
    const meme = computed(() => store.state.meme)

    return {
      title: store.state.titleApp,
      meme
    }
  }
}
</script>

<style lang="scss" scoped></style>
